import 'package:flutter/material.dart';

void main() => runApp(const NbpApp());

const bg = Color(0xFF07110F);
const panel = Color(0xFF10251D);
const panelSelected = Color(0xFF173A2B);
const green = Color(0xFF4CBA7B);
const muted = Color(0xFF8DB5A0);
const white = Color(0xFFF3FFF7);

class DemoMatch {
  final String id, league, time, home, away, market, note;
  final int homePosition, awayPosition;
  final List<String> homeForm, awayForm;

  const DemoMatch({
    required this.id, required this.league, required this.time,
    required this.home, required this.away,
    required this.homePosition, required this.awayPosition,
    required this.homeForm, required this.awayForm,
    required this.market, required this.note,
  });
}

const demoMatches = <DemoMatch>[
  DemoMatch(
    id: 'm1', league: 'ENGLISH LEAGUE · DEMO', time: '16:00',
    home: 'Northbridge FC', away: 'Westport United',
    homePosition: 2, awayPosition: 8,
    homeForm: ['W','W','D','W','L'], awayForm: ['L','W','D','W','L'],
    market: 'Over 1.5 Goals',
    note: 'Sample analysis only. Verified scoring and conceding data would be required before making a real assessment.',
  ),
  DemoMatch(
    id: 'm2', league: 'SPANISH LEAGUE · DEMO', time: '18:30',
    home: 'Valencia Town', away: 'Royal Coast',
    homePosition: 4, awayPosition: 11,
    homeForm: ['W','D','W','W','D'], awayForm: ['L','D','L','W','D'],
    market: 'Over 2.5 Goals',
    note: 'Sample analysis only. Recent results alone are not enough to establish a reliable goals prediction.',
  ),
  DemoMatch(
    id: 'm3', league: 'ITALIAN LEAGUE · DEMO', time: '20:00',
    home: 'Lakeview Calcio', away: 'Capital Athletic',
    homePosition: 6, awayPosition: 7,
    homeForm: ['D','D','W','L','D'], awayForm: ['D','W','D','L','W'],
    market: 'Under 3.5 Goals',
    note: 'Sample analysis only. The production version should use verified match statistics and backtested estimates.',
  ),
];

class NbpApp extends StatelessWidget {
  const NbpApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NBP — Nero Banks Prediction',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: ColorScheme.fromSeed(
          seedColor: green, brightness: Brightness.dark,
          surface: panel,
        ),
        useMaterial3: true,
        appBarTheme: const AppBarTheme(backgroundColor: bg, foregroundColor: white),
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String tab = 'Today';
  String marketFilter = 'All';
  String selectedId = 'm1';
  bool premiumPreview = false;
  final Set<String> saved = {};

  List<DemoMatch> get visibleMatches {
    var matches = demoMatches.where((m) {
      if (tab == 'Saved' && !saved.contains(m.id)) return false;
      if (marketFilter != 'All' && !m.market.startsWith(marketFilter)) return false;
      return true;
    }).toList();
    return matches;
  }

  DemoMatch get selectedMatch =>
      demoMatches.firstWhere((m) => m.id == selectedId, orElse: () => demoMatches.first);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 16,
        title: const Row(children: [
          CircleAvatar(backgroundColor: panelSelected, child: Icon(Icons.emoji_events, color: Color(0xFF7DE0A8))),
          SizedBox(width: 10),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('NBP', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1.2)),
            Text('NERO BANKS PREDICTION', style: TextStyle(fontSize: 9, color: muted, letterSpacing: 1)),
          ]),
        ]),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: TextButton(
              onPressed: () => setState(() => premiumPreview = !premiumPreview),
              child: Text(premiumPreview ? 'FREE VIEW' : 'PREMIUM'),
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(18)),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('WELCOME TO NBP', style: TextStyle(color: muted, fontSize: 11, letterSpacing: 1)),
                const SizedBox(height: 8),
                Text(premiumPreview ? 'Premium preview' : 'Football, analysed simply.',
                    style: const TextStyle(color: white, fontSize: 21, fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                Text(premiumPreview
                    ? 'Preview expanded analysis. No subscription or payment is active.'
                    : 'Compare table positions, recent form and goals-market research in one place.',
                    style: const TextStyle(color: Color(0xFFB3C9BD))),
              ]),
            ),
            const SizedBox(height: 16),
            SegmentedButton<String>(
              segments: const [
                ButtonSegment(value: 'Today', label: Text('Today'), icon: Icon(Icons.today)),
                ButtonSegment(value: 'All matches', label: Text('All matches'), icon: Icon(Icons.sports_soccer)),
                ButtonSegment(value: 'Saved', label: Text('Saved'), icon: Icon(Icons.bookmark_outline)),
              ],
              selected: {tab},
              onSelectionChanged: (value) => setState(() => tab = value.first),
              showSelectedIcon: false,
            ),
            const SizedBox(height: 18),
            Text(tab == 'Saved' ? 'Saved matches' : tab == 'All matches' ? 'All demo fixtures' : 'Today’s match analysis',
                style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold, color: white)),
            const SizedBox(height: 4),
            const Text('DEMO DATA ONLY · NOT LIVE FIXTURES', style: TextStyle(color: muted, fontSize: 10, letterSpacing: .8)),
            const SizedBox(height: 12),
            Wrap(spacing: 8, runSpacing: 8, children: ['All', 'Over 1.5', 'Over 2.5', 'Under 3.5'].map((value) {
              final active = marketFilter == value;
              return ChoiceChip(
                label: Text(value),
                selected: active,
                onSelected: (_) => setState(() => marketFilter = value),
              );
            }).toList()),
            const SizedBox(height: 12),
            if (visibleMatches.isEmpty)
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16)),
                child: const Text('No matches in this view yet. Save a demo match or change the filter.',
                    style: TextStyle(color: muted)),
              ),
            ...visibleMatches.map(_matchCard),
            const SizedBox(height: 16),
            _analysisCard(selectedMatch),
            const SizedBox(height: 16),
            const Center(child: Text(
              'NBP PROTOTYPE · Fictional sample data only',
              style: TextStyle(color: muted, fontSize: 10),
            )),
          ],
        ),
      ),
    );
  }

  Widget _matchCard(DemoMatch m) {
    final isSelected = m.id == selectedId;
    return InkWell(
      onTap: () => setState(() => selectedId = m.id),
      borderRadius: BorderRadius.circular(16),
      child: Container(
        margin: const EdgeInsets.only(top: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: isSelected ? panelSelected : panel,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: isSelected ? green : const Color(0xFF294639)),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: Text(m.league, style: const TextStyle(color: muted, fontSize: 10))),
            Text(m.time, style: const TextStyle(color: muted, fontSize: 11)),
          ]),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(m.home, style: const TextStyle(fontWeight: FontWeight.w700, color: white)),
              Text('League position #${m.homePosition}', style: const TextStyle(color: muted, fontSize: 11)),
            ])),
            const Text('VS', style: TextStyle(color: muted, fontSize: 11)),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              Text(m.away, textAlign: TextAlign.end, style: const TextStyle(fontWeight: FontWeight.w700, color: white)),
              Text('League position #${m.awayPosition}', style: const TextStyle(color: muted, fontSize: 11)),
            ])),
          ]),
          const SizedBox(height: 12),
          Row(children: [
            const Text('FORM ', style: TextStyle(color: muted, fontSize: 10)),
            const SizedBox(width: 4),
            ...m.homeForm.map(_formBadge),
            const Padding(padding: EdgeInsets.symmetric(horizontal: 4), child: Text('/', style: TextStyle(color: muted))),
            ...m.awayForm.map(_formBadge),
          ]),
          const Divider(height: 24, color: Color(0xFF294639)),
          Row(children: [
            const Icon(Icons.sports_soccer, color: muted, size: 18),
            const SizedBox(width: 8),
            Expanded(child: Text(m.market, style: const TextStyle(color: white, fontWeight: FontWeight.w600))),
            const Icon(Icons.chevron_right, color: muted),
          ]),
        ]),
      ),
    );
  }

  Widget _formBadge(String form) {
    final color = form == 'W' ? const Color(0xFF16794A)
        : form == 'D' ? const Color(0xFFA57B27) : const Color(0xFF9C3F47);
    return Container(
      width: 23, height: 23,
      margin: const EdgeInsets.only(right: 3),
      alignment: Alignment.center,
      decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(5)),
      child: Text(form, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
    );
  }

  Widget _analysisCard(DemoMatch m) {
    final isSaved = saved.contains(m.id);
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(18)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Expanded(child: Text('MATCH ANALYSIS', style: TextStyle(color: white, fontSize: 17, fontWeight: FontWeight.bold))),
          Chip(label: const Text('SAMPLE', style: TextStyle(fontSize: 10)), backgroundColor: panelSelected),
        ]),
        Text(m.league, style: const TextStyle(color: muted, fontSize: 10)),
        const SizedBox(height: 8),
        Text('${m.home} vs ${m.away}', style: const TextStyle(color: white, fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        Row(children: [
          _positionBox('HOME POSITION', m.homePosition),
          const SizedBox(width: 10),
          _positionBox('AWAY POSITION', m.awayPosition),
        ]),
        const SizedBox(height: 14),
        Text('Market under review: ${m.market}', style: const TextStyle(color: white, fontWeight: FontWeight.w600)),
        const SizedBox(height: 6),
        Text(m.note, style: const TextStyle(color: Color(0xFFB3C9BD), height: 1.4)),
        if (premiumPreview) ...[
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(border: Border.all(color: const Color(0xFF42684F)), borderRadius: BorderRadius.circular(12)),
            child: const Text(
              'Premium preview: production analysis can include goal averages, home/away splits, head-to-head results, data freshness and backtested estimates.',
              style: TextStyle(color: Color(0xFFB3C9BD), height: 1.4),
            ),
          ),
        ],
        const SizedBox(height: 14),
        SizedBox(width: double.infinity, child: FilledButton.icon(
          onPressed: () => setState(() => isSaved ? saved.remove(m.id) : saved.add(m.id)),
          icon: Icon(isSaved ? Icons.bookmark : Icons.bookmark_add_outlined),
          label: Text(isSaved ? 'Remove from saved' : 'Save match'),
        )),
      ]),
    );
  }

  Widget _positionBox(String label, int position) => Expanded(
    child: Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: panelSelected, borderRadius: BorderRadius.circular(10)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(color: muted, fontSize: 9)),
        const SizedBox(height: 4),
        Text('#$position', style: const TextStyle(color: white, fontSize: 24, fontWeight: FontWeight.bold)),
      ]),
    ),
  );
}
