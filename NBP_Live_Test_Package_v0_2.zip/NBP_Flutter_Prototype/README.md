# Nero Banks Prediction (NBP) — live-data testing package v0.2

This package adds a Flutter live-fixtures test screen and a Cloudflare Worker proxy for API-Football. It is a **testing starter**, not a verified release build. The app will not show live data until you deploy the Worker, add the provider key as a Cloudflare secret, put the Worker URL in `lib/main.dart`, and build/run the Flutter app.

## Files
- `lib/main.dart` — Flutter test UI; requests upcoming fixtures from the Worker.
- `pubspec.yaml` — Flutter dependencies (including `http`).
- `worker_index.js` — Cloudflare Worker API proxy. It does not contain any secret.
- `wrangler.jsonc` — Worker deployment configuration.
- `.gitignore` — excludes local secret files and build output.

## A. Deploy the backend in Cloudflare (dashboard)
1. Open Cloudflare Dashboard → **Workers & Pages** → **Create** → **Worker** (wording may vary).
2. Create a Worker named `nbp-football-proxy` and deploy the starter.
3. Open the Worker → **Edit code**. Replace the starter code with all the contents of `worker_index.js`, then save/deploy.
4. Open the Worker **Settings → Variables and Secrets → Add**. Select **Secret**. Set the variable name to `API_FOOTBALL_KEY`, and paste your API-Football key into the value field. Save and deploy. Do not put the key in Flutter or GitHub.
5. Open the Worker URL (usually `https://nbp-football-proxy.<your-subdomain>.workers.dev`) with `/health` appended. It should return JSON with `ok: true` and `keyConfigured: true`. This health response confirms only that a secret exists; it does not test provider authorization.
6. Test a fixture request in the browser, replacing the example Worker URL with yours: `/fixtures?league=39&season=2026&next=5`. A successful response normally includes a `response` array. If the API provider returns an error, check the JSON `errors` field and your plan/season access.

### Important backend notes
- The Worker currently allows cross-origin requests from any origin to simplify the test. Before public release, restrict `ALLOWED_ORIGIN` to your app's web origin if applicable and add rate limiting/authentication. A mobile app origin is not a reliable security boundary.
- API-Football data coverage and available seasons differ by league. The Worker forwards provider responses and does not invent missing data.
- This is a proxy for testing, not a production-secure public API. Do not publish it widely without abuse protection and licensing review.

## B. Point the Flutter app at the Worker
1. In `lib/main.dart`, find `nbpApiBaseUrl` near the top.
2. Replace `PASTE_YOUR_CLOUDFLARE_WORKER_URL_HERE` with your deployed HTTPS Worker base URL, without a trailing slash.
3. Save the file.

## C. Build/run Flutter
On a computer with Flutter installed, from this folder run:

```bash
flutter pub get
flutter run
```

To build an Android APK:

```bash
flutter build apk --release
```

The APK is normally written to `build/app/outputs/flutter-apk/app-release.apk`.

## Routes provided by Worker
- `GET /health`
- `GET /fixtures?league=39&season=2026&next=15`
- `GET /standings?league=39&season=2026`
- `GET /team-form?team=33&season=2026&last=5&league=39`
- `GET /predictions?fixture=FIXTURE_ID`
- `GET /leagues`

## Current limitations
- Flutter screen currently renders live fixtures only; standings, team form, predictions and BTTS/Over-Under analysis are not yet wired into the UI.
- There is no APK in this ZIP, and this environment does not have a verified Android build result. Do not treat it as installed or connected until you test it.
- Predictions are probabilistic, not guarantees. Verify provider data, competition coverage and licensing before public release or monetization.
