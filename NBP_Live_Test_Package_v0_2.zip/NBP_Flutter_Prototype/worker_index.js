/**
 * NBP API-Football proxy for Cloudflare Workers.
 * Required Cloudflare secret: API_FOOTBALL_KEY
 * Optional plain variable: ALLOWED_ORIGIN (default '*'; tighten for production)
 * Routes: /health, /fixtures?league=39&season=2026&next=10, /standings?league=39&season=2026,
 *         /team-form?team=33&season=2026&last=5&league=39, /predictions?fixture=123456
 */
const API_BASE = 'https://v3.football.api-sports.io';
const corsHeaders = (origin) => ({
  'Access-Control-Allow-Origin': origin || '*',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Content-Type': 'application/json; charset=utf-8',
  'Cache-Control': 'public, max-age=60',
});

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const origin = env.ALLOWED_ORIGIN || '*';
    const headers = corsHeaders(origin);
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers });
    if (request.method !== 'GET') return new Response(JSON.stringify({ error: 'GET only' }), { status: 405, headers });
    if (url.pathname === '/health') return new Response(JSON.stringify({ ok: true, service: 'NBP API proxy', keyConfigured: Boolean(env.API_FOOTBALL_KEY) }), { headers });
    if (!env.API_FOOTBALL_KEY) return new Response(JSON.stringify({ error: 'API_FOOTBALL_KEY secret is not configured in Cloudflare.' }), { status: 503, headers });

    const allowed = new Set(['/fixtures', '/standings', '/team-form', '/predictions', '/leagues']);
    if (!allowed.has(url.pathname)) return new Response(JSON.stringify({ error: 'Unknown route' }), { status: 404, headers });
    const params = new URLSearchParams();
    for (const [key, value] of url.searchParams.entries()) {
      if (!['league','season','next','team','last','fixture','date','from','to','id','country','search','timezone'].includes(key)) continue;
      if (!/^\d{1,6}$/.test(value) && !['date','from','to','country','search','timezone'].includes(key)) return new Response(JSON.stringify({ error: `Invalid parameter: ${key}` }), { status: 400, headers });
      params.set(key, value);
    }
    const required = {
      '/fixtures': ['league','season'], '/standings': ['league','season'],
      '/team-form': ['team','season'], '/predictions': ['fixture'], '/leagues': []
    }[url.pathname];
    for (const key of required) if (!params.has(key)) return new Response(JSON.stringify({ error: `Missing required parameter: ${key}` }), { status: 400, headers });
    if (url.pathname === '/fixtures' && !params.has('next') && !params.has('date') && !params.has('from')) params.set('next','10');
    if (url.pathname === '/team-form' && !params.has('last')) params.set('last','5');
    try {
      const upstream = await fetch(`${API_BASE}${url.pathname}?${params.toString()}`, {
        headers: { 'x-apisports-key': env.API_FOOTBALL_KEY },
      });
      const body = await upstream.text();
      return new Response(body, { status: upstream.status, headers: { ...headers, 'Cache-Control': 'public, max-age=60' } });
    } catch (_) {
      return new Response(JSON.stringify({ error: 'Could not reach football data provider. Try again shortly.' }), { status: 502, headers });
    }
  }
};
