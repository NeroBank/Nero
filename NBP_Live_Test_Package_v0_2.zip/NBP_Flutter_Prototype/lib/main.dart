import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// After deploying the Cloudflare Worker, replace this with its HTTPS URL.
// Example: https://nbp-football-proxy.YOUR-SUBDOMAIN.workers.dev
const String nbpApiBaseUrl = 'PASTE_YOUR_CLOUDFLARE_WORKER_URL_HERE';
const bg = Color(0xFF07110F);
const panel = Color(0xFF10251D);
const green = Color(0xFF4CBA7B);
const muted = Color(0xFF8DB5A0);
const white = Color(0xFFF3FFF7);

void main() => runApp(const NbpApp());

class NbpApp extends StatelessWidget {
  const NbpApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'NBP — Nero Banks Prediction',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(brightness: Brightness.dark, scaffoldBackgroundColor: bg,
      colorScheme: ColorScheme.fromSeed(seedColor: green, brightness: Brightness.dark, surface: panel), useMaterial3: true),
    home: const HomeScreen(),
  );
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final leagueController = TextEditingController(text: '39');
  final seasonController = TextEditingController(text: '2026');
  bool loading = false;
  String? error;
  List<dynamic> fixtures = [];
  Map<String, dynamic>? apiStatus;

  bool get configured => nbpApiBaseUrl.startsWith('https://') && !nbpApiBaseUrl.contains('PASTE_');

  Future<void> loadFixtures() async {
    if (!configured) {
      setState(() => error = 'Setup needed: deploy the Cloudflare Worker, then paste its HTTPS URL into nbpApiBaseUrl in lib/main.dart and rebuild the app.');
      return;
    }
    final league = int.tryParse(leagueController.text.trim());
    final season = int.tryParse(seasonController.text.trim());
    if (league == null || season == null) { setState(() => error = 'Enter numeric league and season IDs.'); return; }
    setState(() { loading = true; error = null; });
    try {
      final uri = Uri.parse('$nbpApiBaseUrl/fixtures').replace(queryParameters: {'league': '$league', 'season': '$season', 'next': '15'});
      final response = await http.get(uri).timeout(const Duration(seconds: 25));
      final body = jsonDecode(response.body);
      if (response.statusCode < 200 || response.statusCode >= 300) throw Exception(body is Map ? (body['error'] ?? body['message'] ?? 'Request failed (${response.statusCode})') : 'Request failed (${response.statusCode})');
      final list = (body is Map ? body['response'] : null);
      if (list is! List) throw Exception('Unexpected response format. Check your Worker URL and API subscription.');
      setState(() { fixtures = list; apiStatus = body is Map ? body : null; });
      if (list.isEmpty) setState(() => error = 'No fixtures were returned for this league/season. Try another league or season.');
    } catch (e) {
      setState(() => error = 'Could not load live fixtures: ${e.toString().replaceFirst('Exception: ', '')}');
    } finally { if (mounted) setState(() => loading = false); }
  }

  String _text(dynamic value, [String fallback = '—']) => value == null ? fallback : '$value';
  String _date(dynamic fixture) {
    final raw = fixture is Map ? fixture['date'] : null;
    if (raw == null) return 'Kickoff time unavailable';
    try { final dt = DateTime.parse('$raw').toLocal(); return '${dt.day.toString().padLeft(2,'0')}/${dt.month.toString().padLeft(2,'0')} ${dt.hour.toString().padLeft(2,'0')}:${dt.minute.toString().padLeft(2,'0')}'; } catch (_) { return '$raw'; }
  }

  @override
  void dispose() { leagueController.dispose(); seasonController.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Row(children: [CircleAvatar(backgroundColor: Color(0xFF173A2B), child: Icon(Icons.emoji_events, color: Color(0xFF7DE0A8))), SizedBox(width: 10), Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('NBP', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1.2)), Text('NERO BANKS PREDICTION', style: TextStyle(fontSize: 9, color: muted, letterSpacing: 1))])])),
    body: SafeArea(child: ListView(padding: const EdgeInsets.all(16), children: [
      Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(18)), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('LIVE DATA TEST', style: TextStyle(color: muted, fontSize: 11, letterSpacing: 1)), SizedBox(height: 8), Text('Football, analysed simply.', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: white)), SizedBox(height: 6), Text('This test loads fixtures from API-Football through your secure Cloudflare Worker. Predictions are not guaranteed.', style: TextStyle(color: Color(0xFFB3C9BD)))])),
      const SizedBox(height: 16),
      Row(children: [Expanded(child: TextField(controller: leagueController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'League ID', hintText: 'e.g. 39', border: OutlineInputBorder()))), const SizedBox(width: 10), Expanded(child: TextField(controller: seasonController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Season year', hintText: 'e.g. 2026', border: OutlineInputBorder())))]),
      const SizedBox(height: 12),
      FilledButton.icon(onPressed: loading ? null : loadFixtures, icon: loading ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.sync), label: Text(loading ? 'Loading fixtures…' : 'Load live fixtures')),
      if (!configured) const Padding(padding: EdgeInsets.only(top: 12), child: Text('Backend not connected yet. The Worker must be deployed and its URL added to the app before live requests can work.', style: TextStyle(color: Color(0xFFFFD180)))),
      if (error != null) Container(margin: const EdgeInsets.only(top: 12), padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: const Color(0xFF38241B), borderRadius: BorderRadius.circular(12)), child: Text(error!, style: const TextStyle(color: Color(0xFFFFD6C2)))),
      const SizedBox(height: 18),
      Row(children: [const Expanded(child: Text('Fixtures', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))), Text('${fixtures.length} loaded', style: const TextStyle(color: muted, fontSize: 12))]),
      const SizedBox(height: 8),
      if (fixtures.isEmpty) Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16)), child: const Text('No live fixtures loaded yet. Configure the backend, then tap “Load live fixtures”.', style: TextStyle(color: muted))),
      ...fixtures.map((item) {
        final f = item is Map ? item['fixture'] as Map? : null;
        final teams = item is Map ? item['teams'] as Map? : null;
        final league = item is Map ? item['league'] as Map? : null;
        final goals = item is Map ? item['goals'] as Map? : null;
        final home = teams?['home'] as Map?;
        final away = teams?['away'] as Map?;
        final homeName = _text(home?['name']);
        final awayName = _text(away?['name']);
        return Container(margin: const EdgeInsets.only(top: 10), padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFF294639))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${_text(league?['name'], 'League')} · ${_date(f)}', style: const TextStyle(color: muted, fontSize: 11)), const SizedBox(height: 10),
          Row(children: [Expanded(child: Text(homeName, style: const TextStyle(fontWeight: FontWeight.bold, color: white))), Text('${_text(goals?['home'])} - ${_text(goals?['away'])}', style: const TextStyle(fontWeight: FontWeight.bold, color: green)), Expanded(child: Text(awayName, textAlign: TextAlign.end, style: const TextStyle(fontWeight: FontWeight.bold, color: white)))]),
          const SizedBox(height: 8), Text('Status: ${_text((f?['status'] as Map?)?['long'], 'Unknown')}', style: const TextStyle(color: muted, fontSize: 11)),
        ]));
      }),
      const SizedBox(height: 20), const Text('Testing note: league positions, form, and prediction markets are not shown as verified until their corresponding endpoints are connected. No betting outcome is guaranteed.', style: TextStyle(color: muted, fontSize: 11)),
    ])),
  );
}
